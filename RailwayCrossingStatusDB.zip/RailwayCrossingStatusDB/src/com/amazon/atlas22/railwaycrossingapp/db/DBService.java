package com.amazon.atlas22.railwaycrossingapp.db;

public class DBService {
}
